local ADDON = ...

local function ApplyD1Texture()
    local texture = "Interface\\AddOns\\MysticallD1RaidFrames\\d1.tga"

    -- Blizzard raid frames are created dynamically, so scan for StatusBars
    -- whenever the frames are shown/rebuilt.
    local function scan(frame)
        if not frame or not frame.GetRegions then return end

        for i = 1, select("#", frame:GetRegions()) do
            local region = select(i, frame:GetRegions())
            if region and region.GetObjectType and region:GetObjectType() == "Texture" then
                -- No-op: health bars are handled below through child frames.
            end
        end

        if frame.GetChildren then
            for i = 1, select("#", frame:GetChildren()) do
                local child = select(i, frame:GetChildren())
                if child and child.SetStatusBarTexture and child.GetStatusBarTexture then
                    child:SetStatusBarTexture(texture)
                end
                scan(child)
            end
        end
    end

    -- Directly target the known Blizzard compact-unit-frame container.
    local manager = CompactRaidFrameContainer
    if manager then scan(manager) end

    -- Also cover party/raid compact frames currently visible.
    for _, name in ipairs({
        "CompactPartyFrame",
        "CompactRaidFrameContainer",
    }) do
        local frame = _G[name]
        if frame then scan(frame) end
    end

    -- Individual compact unit frames are named dynamically; catch visible
    -- frames through the compact-frame iterator when available.
    if CompactUnitFrameIterator then
        for frame in CompactUnitFrameIterator() do
            if frame then scan(frame) end
        end
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:SetScript("OnEvent", function()
    C_Timer.After(0, ApplyD1Texture)
    C_Timer.After(0.5, ApplyD1Texture)
end)

-- Reapply after Blizzard compact frames update their layout.
hooksecurefunc("CompactUnitFrame_UpdateAll", function()
    C_Timer.After(0, ApplyD1Texture)
end)
